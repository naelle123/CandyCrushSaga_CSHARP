﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CandyCrushSaga
{
    public partial class progress : Form
    {
        public progress()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pb.Value < 100)
            {
                pb.Value += 1;

            }
            else
            {
                timer1.Stop();
                Main jeux = new Main();
                jeux.Show();
                this.Hide();
            }
        }

        private void progress_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
