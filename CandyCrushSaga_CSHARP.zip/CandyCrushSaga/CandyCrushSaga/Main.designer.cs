﻿using System.Drawing;
using System.Windows.Forms;

namespace CandyCrushSaga
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            ThemeWrapper = new UI.MonoControls.MonoTheme();
            label4 = new Label();
            toggleSpeed = new UI.MonoControls.MonoToggle();
            lblScore = new Label();
            label3 = new Label();
            label2 = new Label();
            txtGridWidth = new UI.MonoControls.MonoTextBox();
            label1 = new Label();
            txtGridHeight = new UI.MonoControls.MonoTextBox();
            screen = new PictureBox();
            btnLoadValues = new UI.MonoControls.MonoButton();
            monoControlBox1 = new UI.MonoControls.MonoControlBox();
            ThemeWrapper.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)screen).BeginInit();
            SuspendLayout();
            // 
            // ThemeWrapper
            // 
            ThemeWrapper.AcceptButton = null;
            ThemeWrapper.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ThemeWrapper.BackColor = Color.FromArgb(22, 31, 40);
            ThemeWrapper.BorderRadius = 4;
            ThemeWrapper.CancelButton = null;
            ThemeWrapper.ControlBox = true;
            ThemeWrapper.ControlMode = false;
            ThemeWrapper.Controls.Add(label4);
            ThemeWrapper.Controls.Add(toggleSpeed);
            ThemeWrapper.Controls.Add(lblScore);
            ThemeWrapper.Controls.Add(label3);
            ThemeWrapper.Controls.Add(label2);
            ThemeWrapper.Controls.Add(txtGridWidth);
            ThemeWrapper.Controls.Add(label1);
            ThemeWrapper.Controls.Add(txtGridHeight);
            ThemeWrapper.Controls.Add(screen);
            ThemeWrapper.Controls.Add(btnLoadValues);
            ThemeWrapper.Controls.Add(monoControlBox1);
            ThemeWrapper.Dock = DockStyle.Fill;
            ThemeWrapper.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            ThemeWrapper.ForeColor = Color.White;
            ThemeWrapper.HeaderBackColor = Color.FromArgb(22, 31, 40);
            ThemeWrapper.HeaderHeight = 36;
            ThemeWrapper.Icon = (Icon)resources.GetObject("ThemeWrapper.Icon");
            ThemeWrapper.IsMdiContainer = false;
            ThemeWrapper.KeyPreview = false;
            ThemeWrapper.Location = new Point(0, 0);
            ThemeWrapper.MainMenuStrip = null;
            ThemeWrapper.Margin = new Padding(4, 5, 4, 5);
            ThemeWrapper.MinimizeBox = true;
            ThemeWrapper.Name = "ThemeWrapper";
            ThemeWrapper.Opacity = 1D;
            ThemeWrapper.Padding = new Padding(15, 65, 15, 15);
            ThemeWrapper.RightToLeftLayout = false;
            ThemeWrapper.RoundCorners = true;
            ThemeWrapper.ShowIcon = true;
            ThemeWrapper.ShowInTaskbar = true;
            ThemeWrapper.Sizable = false;
            ThemeWrapper.Size = new Size(1108, 837);
            ThemeWrapper.SizeGripStyle = SizeGripStyle.Hide;
            ThemeWrapper.SmartBounds = true;
            ThemeWrapper.StartPosition = FormStartPosition.CenterScreen;
            ThemeWrapper.TabIndex = 0;
            ThemeWrapper.Text = "Candy Crush Saga Algorithm";
            ThemeWrapper.TopMost = false;
            ThemeWrapper.TransparencyKey = Color.Fuchsia;
            ThemeWrapper.WindowState = FormWindowState.Normal;
            ThemeWrapper.Resize += ThemeWrapper_Resize;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(12, 727);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(123, 28);
            label4.TabIndex = 13;
            label4.Text = "Super Speed";
            // 
            // toggleSpeed
            // 
            toggleSpeed.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            toggleSpeed.BackColor = Color.Transparent;
            toggleSpeed.FillColor = Color.FromArgb(181, 41, 42);
            toggleSpeed.ForeColor = Color.White;
            toggleSpeed.ForeColor2 = Color.White;
            toggleSpeed.Location = new Point(20, 764);
            toggleSpeed.Margin = new Padding(4, 5, 4, 5);
            toggleSpeed.Name = "toggleSpeed";
            toggleSpeed.Size = new Size(76, 33);
            toggleSpeed.TabIndex = 12;
            toggleSpeed.Text = "monoToggle1";
            toggleSpeed.ThumbColor = Color.White;
            toggleSpeed.Toggled = false;
            toggleSpeed.Type = UI.MonoControls.MonoToggle.ToggleType.OnOff;
            toggleSpeed.ToggledChanged += toggleSpeed_ToggledChanged;
            // 
            // lblScore
            // 
            lblScore.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblScore.Location = new Point(18, 360);
            lblScore.Margin = new Padding(4, 0, 4, 0);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(207, 103);
            lblScore.TabIndex = 11;
            lblScore.Text = "0";
            lblScore.TextAlign = ContentAlignment.MiddleCenter;
            lblScore.Click += lblScore_Click;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(18, 328);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(207, 39);
            label3.TabIndex = 10;
            label3.Text = "Score";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(12, 273);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(104, 28);
            label2.TabIndex = 9;
            label2.Text = "Horizontal";
            // 
            // txtGridWidth
            // 
            txtGridWidth.BackColor = Color.Transparent;
            txtGridWidth.FillColor = Color.FromArgb(66, 76, 85);
            txtGridWidth.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            txtGridWidth.ForeColor = Color.FromArgb(176, 183, 191);
            txtGridWidth.HighlightColor = Color.White;
            txtGridWidth.Image = null;
            txtGridWidth.Location = new Point(18, 202);
            txtGridWidth.Margin = new Padding(4, 5, 4, 5);
            txtGridWidth.MaxLength = 50000;
            txtGridWidth.Multiline = false;
            txtGridWidth.Name = "txtGridWidth";
            txtGridWidth.ReadOnly = false;
            txtGridWidth.Size = new Size(118, 47);
            txtGridWidth.TabIndex = 8;
            txtGridWidth.Text = "18";
            txtGridWidth.TextAlignment = HorizontalAlignment.Left;
            txtGridWidth.UseSystemPasswordChar = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(18, 141);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(76, 28);
            label1.TabIndex = 7;
            label1.Text = "Vertical";
            // 
            // txtGridHeight
            // 
            txtGridHeight.BackColor = Color.Transparent;
            txtGridHeight.FillColor = Color.FromArgb(66, 76, 85);
            txtGridHeight.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            txtGridHeight.ForeColor = Color.FromArgb(176, 183, 191);
            txtGridHeight.HighlightColor = Color.White;
            txtGridHeight.Image = null;
            txtGridHeight.Location = new Point(18, 69);
            txtGridHeight.Margin = new Padding(4, 5, 4, 5);
            txtGridHeight.MaxLength = 50000;
            txtGridHeight.Multiline = false;
            txtGridHeight.Name = "txtGridHeight";
            txtGridHeight.ReadOnly = false;
            txtGridHeight.Size = new Size(118, 47);
            txtGridHeight.TabIndex = 6;
            txtGridHeight.Text = "18";
            txtGridHeight.TextAlignment = HorizontalAlignment.Left;
            txtGridHeight.UseSystemPasswordChar = false;
            // 
            // screen
            // 
            screen.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            screen.BackColor = Color.Transparent;
            screen.Cursor = Cursors.Hand;
            screen.Location = new Point(244, 69);
            screen.Margin = new Padding(4, 5, 4, 5);
            screen.Name = "screen";
            screen.Size = new Size(844, 748);
            screen.TabIndex = 5;
            screen.TabStop = false;
            screen.MouseDown += screen_MouseDown;
            screen.MouseMove += screen_MouseMove;
            screen.MouseUp += screen_MouseUp;
            // 
            // btnLoadValues
            // 
            btnLoadValues.BackColor = Color.Transparent;
            btnLoadValues.Cursor = Cursors.Hand;
            btnLoadValues.FillColor = Color.FromArgb(181, 41, 42);
            btnLoadValues.FillColor2 = Color.FromArgb(165, 37, 37);
            btnLoadValues.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnLoadValues.ForeColor = Color.FromArgb(255, 255, 255);
            btnLoadValues.Image = null;
            btnLoadValues.ImageAlign = ContentAlignment.MiddleLeft;
            btnLoadValues.ImageSize = new Size(46, 46);
            btnLoadValues.Location = new Point(45, 468);
            btnLoadValues.Margin = new Padding(4, 5, 4, 5);
            btnLoadValues.Name = "btnLoadValues";
            btnLoadValues.RoundCorners = true;
            btnLoadValues.Size = new Size(158, 55);
            btnLoadValues.TabIndex = 2;
            btnLoadValues.Text = "New Session";
            btnLoadValues.TextAlignment = StringAlignment.Center;
            btnLoadValues.Click += btnLoadValues_Click;
            // 
            // monoControlBox1
            // 
            monoControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            monoControlBox1.AutoRelocate = true;
            monoControlBox1.BackColor = Color.FromArgb(22, 31, 40);
            monoControlBox1.BackColor2 = Color.FromArgb(64, 64, 64);
            monoControlBox1.Cursor = Cursors.Hand;
            monoControlBox1.EnableHoverHighlight = true;
            monoControlBox1.EnableMaximizeButton = true;
            monoControlBox1.EnableMinimizeButton = true;
            monoControlBox1.ForeColor = Color.Silver;
            monoControlBox1.ForeColor2 = Color.FromArgb(192, 64, 0);
            monoControlBox1.Location = new Point(1008, 0);
            monoControlBox1.Margin = new Padding(4, 5, 4, 5);
            monoControlBox1.Name = "monoControlBox1";
            monoControlBox1.Size = new Size(100, 25);
            monoControlBox1.TabIndex = 0;
            monoControlBox1.Text = "monoControlBox1";
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(1108, 837);
            Controls.Add(ThemeWrapper);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 5, 4, 5);
            MinimumSize = new Size(874, 775);
            Name = "Main";
            SizeGripStyle = SizeGripStyle.Hide;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Candy Crush Saga Algorithm";
            TransparencyKey = Color.Fuchsia;
            ThemeWrapper.ResumeLayout(false);
            ThemeWrapper.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)screen).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private UI.MonoControls.MonoTheme ThemeWrapper;
        private UI.MonoControls.MonoControlBox monoControlBox1;
        private UI.MonoControls.MonoButton btnLoadValues;
        private PictureBox screen;
        private UI.MonoControls.MonoTextBox txtGridHeight;
        private Label label2;
        private UI.MonoControls.MonoTextBox txtGridWidth;
        private Label label1;
        private Label lblScore;
        private Label label3;
        private UI.MonoControls.MonoToggle toggleSpeed;
        private Label label4;
    }
}

